import { useState, useEffect, useRef } from 'react';
import { View, Text, Image, TextInput, Animated, Easing, StyleSheet, Alert, TouchableOpacity, ImageBackground, KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { Switch } from 'react-native';
import * as SecureStore from 'expo-secure-store'; // For saving login state later
import axios, { AxiosError } from 'axios';
import * as Utils from '../../utils/utils';


export default function RegisterScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  //const [phoneNumber, setNumber] = useState(''); // Delete later
  const [userName, setUserName] = useState('');
  const [isLocationEnabled, setIsLocationEnabled] = useState(true); // default: ON

  //Email format check
  const isValidEmail = (email: string) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  const slideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const keyboardWillShow = Keyboard.addListener('keyboardWillShow', () => {
      Animated.timing(slideAnim, {
        toValue: -70, // pixels to move up
        duration: 350,
        easing: Easing.out(Easing.poly(4)),
        useNativeDriver: true,
      }).start();
    });
  
    const keyboardWillHide = Keyboard.addListener('keyboardWillHide', () => {
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 200,
        easing: Easing.in(Easing.poly(1)),
        useNativeDriver: true,
      }).start();
    });
  
    return () => {
      keyboardWillShow.remove();
      keyboardWillHide.remove();
    };
  }, []);
  
  // TODO: Strong password validation


  //check inputs validations
  const handleRegister = async () => {
    if (!email || !password || !confirmPassword || !userName) {
      Alert.alert('Error', 'Please fill out all fields.');
      return;
    }
  
    if (!isValidEmail(email)) {
      Alert.alert('Error', 'Please enter a valid email address.');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match.');
      return;
    }
  
    try {
      if (isLocationEnabled) {
        const granted = await Utils.requestForegroundLocationPermission();
        if (!granted) return; // Stop registration if permission was denied
      }

      const res = await axios.post(
         Utils.currentPath + 'auth/signup',
        {
          email,
          password,
          //phone: phoneNumber, // Delete later
          display_name: userName,
          geo_alert: isLocationEnabled,
        }
      );
      console.log('[SIGNUP SUCCESS]', res.data);
      await Utils.save('user_id', res.data.user_id); // Save user ID to secure storage
      await Utils.save('access_token', res.data.access_token); // Save access token to secure storage
      router.push('/(dashboard)/(tabs)/home');
  
    } catch (err) {
      const error = err as AxiosError<{ detail: string }>;
      console.log(error);
      console.log(err);
      console.log('[SIGNUP ERROR]', error.response?.data?.detail || 'Unknown error');
      Alert.alert('Signup failed', error.response?.data?.detail || 'Unknown error');
    }
  };

  return (
    <ImageBackground source={require('../../assets/images/registerBG.png')} resizeMode="cover" style={styles.image}>
     <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
    <Animated.View style={[styles.container, { transform: [{ translateY: slideAnim }] }]}>

    <View style={{alignItems: 'center'}}> 
      <Image
        style={styles.logo}
        source={require('../../assets/images/logo1.png')}/>
        </View>
      <Text style={styles.title}>Welcome to NearBuy </Text>
      <Text style={styles.subtitle}>Create a new account</Text>
      <TextInput
        placeholder="Name"
        style={styles.input}
        keyboardType="default" //capitalize first letter of names
        autoCapitalize="words"
        value={userName}
        onChangeText={setUserName}
      />
      <TextInput
        placeholder="Email"
        style={styles.input}
        autoCapitalize="none"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        placeholder="Password"
        secureTextEntry
        style={styles.input}
        value={password}
        onChangeText={setPassword}
      />
      <TextInput
        placeholder="Confirm Password"
        secureTextEntry
        style={styles.input}
        value={confirmPassword}
        onChangeText={setConfirmPassword}
      />

      <View style={styles.toggleContainer}>
        <Text style={styles.toggleLabel}>Want to turn on location-based notifications by default?</Text>
        <Switch
          value={isLocationEnabled}
          onValueChange={setIsLocationEnabled}
          trackColor={{ false: '#ccc', true: '#007AFF' }}
          thumbColor={isLocationEnabled ? '#fff' : '#f4f3f4'}
        />
      </View>

      <View style={styles.underToggle}> 
        <Text style={styles.smallerToggleLabel}>Don't worry - you can always turn this off later</Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <Text style={styles.buttonText}>REGISTER</Text>
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Already have an account?</Text>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.footerLink}> Login</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
    </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1,
    justifyContent: 'center', 
    alignItems: 'center',
    padding: 24, 
    //marginBottom: 20,
    //backgroundColor: '#FAFAFA'
  },
  
  title: {
    fontSize: 27,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    color: '#5067b2',
  },
  subtitle: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 24,
    color: '#332F6E',
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 11,
    marginBottom: 16,
    fontSize: 16,
    backgroundColor: '#FAFAFA',
    width: 320,
  },
  button: {
    backgroundColor: '#B25FC3', // 🔁 Change to your preferred color
    borderRadius: 50,           // Fully rounded
    paddingVertical: 14,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 10,
    width: 200,
    // Shadow for iOS
    shadowColor: '#000',
    shadowOffset: { width: 1, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
  
    // Shadow for Android
    elevation: 3,
  },
  buttonText: {
    color: 'white',
    fontSize: 15,
    fontWeight: 'bold',
  },
  footer: { 
    flexDirection: 'row', 
    justifyContent: 'center', 
    marginTop: 16 
  },
  footerText: { 
    fontSize: 14, 
    color: '#555' 
  },
  footerLink: { 
    fontSize: 14, 
    color: '#007AFF', 
    fontWeight: '500' 
  },

  toggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    marginHorizontal: 50,
  },
  
  toggleLabel: {
    fontSize: 14,
    color: '#333',
  },
  underToggle: { 
    flexDirection: 'row', 
    justifyContent: 'center',
    marginBottom: 12,
  },
  smallerToggleLabel: {
    fontSize: 12,
    color: '#333',
  },
  image: {
    flex: 1,
  },
  logo: {
    width: 55,
    height: 89,
    marginBottom: 16,
  },
});
